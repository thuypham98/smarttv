﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCuaHangTivi
{
    class Khachhang
    {
        //CÁC THUỘC TÍNH DỮ LIỆU
        private string Makh, Tenkh,Diachi;
        private int SoDT;

        public string MAKH
        {
            get { return Makh; }
            set { Makh = value; }
        }
        public string TENKH
        {
            get { return Tenkh; }
            set { Tenkh = value; }
        }
        public string DIACHI
        {
            get { return Diachi; }
            set { Diachi = value; }
        }
        public int SDT
        {
            get { return SoDT; }
            set { SoDT = value; }
        }
        // Các phương thức khởi tạo
        public Khachhang()
        {
            this.Makh = "";
            this.Tenkh = "";
            this.Diachi = "";
            this.SoDT = 0;
        }
        public Khachhang(string Makh, string Tenkh, string Diachi, int SoDT)
        {
            this.Makh = Makh;
            this.Tenkh = Tenkh;
            this.Diachi = Diachi;
            this.SoDT = SoDT;
        }
        public Khachhang(Khachhang KH)
        {
            this.Makh = KH.Makh;
            this.Tenkh = KH.Tenkh;
            this.Diachi = KH.Diachi;
            this.SoDT = KH.SoDT;
        }
        // CÁC PHƯƠNG THỨC XỬ LÍ
        //Phương thức nhập
        public void Nhap()
        {
            DSKH ds = new DSKH();
            ds.ReadFile("D://KhachHang.txt");
            //Kiểm tra mã khách hàng đã tồn tại hay chưa
            do
            {
                do
                {
                    Console.Write("\nNhap ma khach hang:");
                    Makh = Console.ReadLine();
                    if (Makh == "")
                        Console.WriteLine("Ma khach hang khong duoc de trong");
                } while (Makh == "");
                if (ds.KtraMaKH(Makh) == true)
                {
                    Console.WriteLine("Ma khach hang da ton tai. Vui long nhap lai:");
                }
            }
            while (ds.KtraMaKH(Makh) == true);
            Console.Write("Nhap ten khach hang :  ");
            Tenkh = Console.ReadLine();
            Console.Write("Dia chi khach hang: ");
            Diachi = Console.ReadLine();
            Console.Write("So dien thoai: ");
            SoDT = int.Parse(Console.ReadLine());
        }

        //PHƯƠNG THỨC CẬP NHẬT
        public void CapNhatKH()
        {
            DSKH ds = new DSKH();
            ds.ReadFile("D://SanPham.txt");
            string MaKh;
            string TenKh = "";
            string DiaChi;
            int SDT = 0;
            Console.Write("Nhap noi dung moi hoac an Enter de bo qua: ");

            //Cập nhật mã khách hàng
            do
            {
                Console.Write("\nNhap ma khách hàng:");
                MaKh = Console.ReadLine();
                if (ds.KtraMaKH(MaKh) == true)
                {
                    Console.WriteLine("Ma khach hang da ton tai. Vui long nhap lai:");
                }
            }
            while (ds.KtraMaKH(MaKh) == true);
            if (MaKh.Trim().Length > 0)
                this.Makh = MaKh;

            //Cập nhật Tên khách hàng
            Console.Write("Nhap Ten khách hàng: ");
            TenKh = Console.ReadLine();
            if (MaKh.Trim().Length > 0)
                this.Tenkh = TenKh;

            //Cập nhật địa chỉ khách hàng
            Console.Write("Nhap dia chi khach hang: ");
            DiaChi = Console.ReadLine();
            if (DiaChi.Trim().Length > 0)
                this.Diachi = DiaChi;
            //Cập nhật số điện thoại
            Console.Write("Nhap so dien thoai: ");
            SDT = int.Parse(Console.ReadLine());
            if (SDT > 0)
                this.SoDT = SDT;
        }

        //PHƯƠNG THỨC toString(chuyển đối tượng thành 1 chuỗi)
        public String toString()
        {
            string str = Makh + "#" + Tenkh + "#" + Diachi + "#" + SoDT;
            return str;
        }

        //PHƯƠNG THỨC HIỂN THỊ
        public void Hien()
        {

            Console.WriteLine(" \t{0}\t{1}\t\t{2}\t\t{3} ", Makh, Tenkh, Diachi,SoDT);

        }
    }
}
