﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace QLCuaHangTivi
{
    class DSKH
    {
        private List<Khachhang> list;
        public DSKH()
        {
            list = new List<Khachhang>();
        }

        public void Hien()
        {
            int stt = 1;
            Console.WriteLine("STT\tMa KH\tTen KH\t\tDia chi\t\tSDT");
            foreach (Khachhang kh in list)
            {
                Console.Write("{0}", stt);
                kh.Hien();
                stt++;
            }
        }
        public bool KtraMaKH(string makh) // phục vụ hoá đơn bán, nếu mà sl trong kho ít hơn sl trong hdb vừa nhập
        {
            bool kt = false;

            foreach (Khachhang sp in list)
            {
                if (sp.MAKH == makh)// rktra
                {
                    kt = true; // thay đổi gtri biến ktra// quên chưa CÓ >'< cho luôm d
                }
            }
            return kt;
        }

        public void HienKHTheoMa(string MaKh)
        {
            Console.WriteLine("STT\tMa kh\tTen KH\t\tDia chi\t\tSDT");
            foreach (Khachhang kh in list)
            {
                if (kh.MAKH == MaKh)
                    kh.Hien();
            }
        }

        //Đọc file 
        public void ReadFile(String fileName)
        {
            list = new List<Khachhang>();
            StreamReader str = new StreamReader(new FileStream(fileName, FileMode.Open));
            String strTmp;
            String[] tmp;
            while (!str.EndOfStream)
            {
                strTmp = str.ReadLine().Trim();
                if (strTmp != "")
                {
                    tmp = strTmp.Split('#');
                    list.Add(new Khachhang((tmp[0]), (tmp[1]), (tmp[2]), (int.Parse(tmp[3]))));
                }
            }
            str.Close();
        }

        //Ghi file
        public void WriteFile(String fileName)
        {
            StreamWriter str = new StreamWriter(fileName, false);
            foreach (Khachhang kh in list)
                str.WriteLine(kh.toString());
            str.Close();
        }

        public void ThemMoi(String fileName)
        {
            ConsoleKeyInfo chon;
            Khachhang kh = new Khachhang();
            while (true)
            {
                do
                {
                    Console.Write("Ban muon them moi mot khach hang: (C=Co)/(K=Khong) : ");
                    chon = Console.ReadKey();

                } while (!(chon.KeyChar.ToString().ToUpper() == "C" || chon.KeyChar.ToString().ToUpper() == "K"));
                if (chon.KeyChar.ToString().ToUpper() == "K")
                    break; // Thoát khỏi cấu trúc while
                else // Nhập thông tin của khách hàng mới nếu người dùng nhập Y
                {
                    kh.Nhap();
                    //Them sản phẩm vao list
                    list.Add(kh);
                    //ghi du lieu vao cuoi file
                    StreamWriter str = new StreamWriter(new FileStream(fileName, FileMode.Append));
                    str.WriteLine(kh.toString());
                    str.Close();
                }
            }
        }

        public void CapNhat()
        {

            string MaKH;
            Console.WriteLine("==========================================");
            Console.WriteLine("        SUA THONG TIN KHACH HANG!!!         ");
            Console.WriteLine("==========================================");
            Console.Write("Nhap ma khach hang muon sua:");
            MaKH = Console.ReadLine();

            Khachhang kh = TimkiemTheoMa(MaKH);
            if (kh == null)
                Console.WriteLine("KHONG CO MA KHACH HANG: {0} TRONG DANH SACH !?", MaKH);
            else
            {
                kh.Hien();
                kh.CapNhatKH();
                Console.WriteLine("Sua thong tin khach hang thanh cong.");
            }
        }

        public void Xoa(String MaKH)
        {
            //int i = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].MAKH == MaKH)
                {
                    list.RemoveAt(i);
                    break;
                }
            }
        }

        public void Nhap()
        {
            int stt = 1;
            foreach (Khachhang kh in list)
            {
                Console.Write("{0,-3}", stt);
                kh.Nhap();
                stt++;
            }
        }
        public void TimkiemTheoTenKH(string TenKH)
        {
            int dem = 0;
            Console.WriteLine("STT\tMa KH\tTen KH\t\tDia chi\t\tSDT");
            foreach (Khachhang kh in list)
            {
                if (kh.TENKH == TenKH)
                {
                    kh.Hien();
                    dem++;
                }
            }
            if (dem == 0)
                Console.WriteLine("Khong co ten khach hang la: {0}", TenKH);
        }

        public Khachhang TimkiemTheoMa(string Makh)
        {
            for (int i = 0; i < list.Count; i++)
                if (Makh.CompareTo(list[i].MAKH) == 0)
                {
                    return list[i];
                }
            return null;
        }


        public int Count()
        {
            int t = 0;
            foreach (Khachhang kh in list)
            {
                if (kh.MAKH != "")
                    t = t + 1;
            }
            return t;
        }

        public void MenuKhachHang()
        {
            Console.Title = "\t";
            bool stop = false;
            while (!stop)
            {
                Console.Clear();
                //Console.SetWindowSize(115, 50);
                Console.Write("                      ╔═══════════════════════════════════════════════════════════════════╗\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ║     F1 : Hiển Thị DS Khách Hàng       F2 : Thêm Khách Hàng Mới    ║\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ║     F3 : Cập Nhật Khách Hàng          F4 : Xóa Khách Hàng         ║\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ║     F5 : Tìm Kiếm Khách Hàng          F6 : Quay Lại Menu Chính    ║\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ╚═══════════════════════════════════════════════════════════════════╝\n\n");

                Console.Write("                                       Mời Bạn Chọn Phím Chức Năng: ");
                //Console.SetCursorPosition(52, 22);
                ConsoleKeyInfo kt = Console.ReadKey();
                Console.Clear();
                DSKH KH = new DSKH();
                KH.ReadFile("D:\\KhachHang.txt");
                switch (kt.Key)
                {
                    case ConsoleKey.F1:
                        KH.Hien();
                        Console.ReadKey();
                        break;
                    case ConsoleKey.F2:
                        KH.ThemMoi("D:\\KhachHang.txt");
                        break;
                    case ConsoleKey.F3:
                        KH.CapNhat();
                        KH.Hien();
                        KH.WriteFile("D:\\KhachHang.txt");
                        Console.ReadKey();
                        break;
                    case ConsoleKey.F4:
                        Console.WriteLine(" Nhap ma khach hang can xoa: ");
                        string MaKH = Console.ReadLine();
                        Khachhang kh = KH.TimkiemTheoMa(MaKH);
                        if (kh == null)
                            Console.WriteLine(" Khong co khach hang co ma : {0}. ", MaKH);
                        else
                        {
                            KH.Xoa(MaKH);
                            KH.Hien();
                            KH.WriteFile("D:\\KhachHang.txt");
                            Console.ReadKey();
                        }
                        break;
                    case ConsoleKey.F5:// Hiện danh sách
                        Console.Write("\nNhap ten khach hang can tim kiem : ");
                        string TenKH = Console.ReadLine();
                        KH.TimkiemTheoTenKH(TenKH);
                        Console.ReadKey();
                        break;
                    case ConsoleKey.F6:
                        // Environment.Exit(0);
                        return;
                    //  break;
                    default:
                        break;
                }
            }
        }
    }
}
