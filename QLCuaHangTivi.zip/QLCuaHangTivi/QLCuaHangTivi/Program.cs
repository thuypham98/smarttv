﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace QLCuaHangTivi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            DangNhap();
            MenuChinh();
            Console.ReadKey();
        }
        static void DangNhap()
        {
            string a, b;
            int count = 0;
            Console.WriteLine("---ĐĂNG NHẬP HỆ THỐNG---");
            do
            {
                Console.Write("-->> Username:"); count++;
                a = Console.ReadLine();
                Console.Write("-->> Password:");
                b = Console.ReadLine();
                if ((a == "tk") && (b == "141"))
                    Console.WriteLine("Đăng Nhập Thành Công!!!");
                else Console.WriteLine("Không Chính Xác,Mời Nhập Lại... : ");
            } while ((a != "tk" || b != "141") && (count < 5));
        }

        static void MenuChinh()
        {
            while (true)
            {
                Console.Clear();
                Console.Write("                          ══════════════════════════════════════════════════\n");
                Console.WriteLine("                          ║       CHƯƠNG TRÌNH QUẢN LÝ CỬA HÀNG TIVI       ║");
                Console.WriteLine("                          ║             1: Quản lý Sản Phẩm                ║");
                Console.WriteLine("                          ║             2: Quản lý Khách Hàng              ║");
                Console.WriteLine("                          ║             3: Quản lý Hóa Đơn Nhập            ║");
                Console.WriteLine("                          ║             4: Quản lý Hóa Đơn Xuất            ║");
                Console.WriteLine("                          ║             5: Thoát                           ║");
                Console.Write("                          ══════════════════════════════════════════════════\n");
                Console.WriteLine();
                Console.Write("                                     Mời Bạn Chọn Phím Chức Năng: ");
                                                                
                string chon = Console.ReadLine();

                Console.Clear();
                switch (chon)
                {
                    case "1":
                        DSTV DSTiVi = new DSTV();
                        DSTiVi.MenuSanPham();
                        break;
                    case "2":
                        DSKH DSKhachHang = new DSKH();
                        DSKhachHang.MenuKhachHang();
                        break;
                    //case "3":
                    //    QLHoaDonNhap dsHDNhap = new QLHoaDonNhap();
                    //    dsHDNhap.MenuDShoadonnhap();
                    //    break;
                    //case "4":
                    //    QLHoaDonBan dsHDBan = new QLHoaDonBan();
                    //    dsHDBan.MenuHDBan();
                    //    break;
                    case "5": Console.Clear(); Environment.Exit(0); break;
                }
            }
        }
    }
}
