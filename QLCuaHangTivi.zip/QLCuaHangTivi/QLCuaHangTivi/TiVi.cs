﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLCuaHangTivi
{
    class TiVi
    {
        //CÁC THUỘC TÍNH DỮ LIỆU
        private string Masp, Tensp, Ngaynhap;
        private int Soluong;
        private double Gianhap, Giaban;
        //THUỘC TÍNH
        public string MASP
        {
            get { return Masp; }
            set { Masp = value; }
        }
        public string TENSP
        {
            get { return Tensp; }
            set { Tensp = value; }
        }
        public string NGAYNHAP
        {
            get { return Ngaynhap; }
            set { Ngaynhap = value; }
        }
        public int SOLUONG
        {
            get { return Soluong; }
            set { Soluong = value; }
        }
        public double GIANHAP
        {
            get { return Gianhap; }
            set { Gianhap = value; }
        }
        public double GIABAN
        {
            get { return Giaban; }
            set { Giaban = value; }
        }
        //CÁC PHƯƠNG THỨC KHỞI TẠO
        public TiVi()
        {
            this.Masp = "";
            this.Tensp = "";
            this.Ngaynhap = "";
            this.Gianhap = 0;
            this.Giaban = 0;
            this.Soluong = 0;
        }
        public TiVi(string Masp, string Tensp, string Ngaynhap, int Soluong, double Gianhap, double Giaban)
        {
            this.Masp = Masp;
            this.Tensp = Tensp;
            this.Ngaynhap = Ngaynhap;
            this.Gianhap = Gianhap;
            this.Giaban = Giaban;
            this.Soluong = Soluong;
        }
        public TiVi(TiVi TV)
        {
            this.Masp = TV.Masp;
            this.Tensp = TV.Tensp;
            this.Ngaynhap = TV.Ngaynhap;
            this.Gianhap = TV.Gianhap;
            this.Giaban = TV.Giaban;
            this.Soluong = TV.Soluong;
        }
        // CÁC PHƯƠNG THỨC XỬ LÍ
        //Phương thức nhập
        public void Nhap()
        {
            DSTV ds = new DSTV();
            ds.ReadFile("D://SanPham.txt");
            bool validate;
            //Kiểm tra mã tivi đã tồn tại hay chưa
            do
            {
                do
                {
                    Console.Write("\nNhap ma Tivi:");
                    Masp = Console.ReadLine();
                    if (Masp == "")
                        Console.WriteLine("Ma Tivi khong duoc de trong");
                } while (Masp == "");
                if (ds.KtraMaSP(Masp) == true)
                {
                    Console.WriteLine("Ma Tivi da ton tai. Vui long nhap lai:");
                }
            }
            while (ds.KtraMaSP(Masp) == true);

            Console.Write("Nhap ten san pham :  ");
            Tensp = Console.ReadLine();
            do
            {
                do
                {
                    Console.Write("Nhap so luong (so luong>0): ");
                    validate = int.TryParse(Console.ReadLine().Replace(" ", ""), out Soluong);
                } while (validate == false);
            } while (Soluong <= 0);
            do
            {
                do
                {
                    Console.Write("Nhap gia nhap (gia nhap>0): ");
                    validate = double.TryParse(Console.ReadLine().Replace(" ", ""), out Gianhap);
                } while (validate == false);

            } while (Gianhap <= 0);
            do
            {
                do
                {
                    Console.Write("Nhap gia ban(gia ban>0):");
                    validate = double.TryParse(Console.ReadLine().Replace(" ", " "), out Giaban);
                } while (validate == false);
            } while (Giaban <= 0 || Giaban <= Gianhap);

            Console.Write("Ngay nhap hang :");
            Ngaynhap = Console.ReadLine();
        }

        //PHƯƠNG THỨC CẬP NHẬT
        public void CapNhatSP()
        {
            DSTV ds = new DSTV();
            ds.ReadFile("D://SanPham.txt");
            string MaSp;
            string TenSp = "";
            string Ngaynhap;
            int Soluong = 0;
            double Gianhap = 0;
            double Giaban = 0;
            Console.Write("Nhap noi dung moi hoac an Enter de bo qua: ");

            //Cập nhật mã sản phẩm
            do
            {
                Console.Write("\nNhap ma san pham:");
                MaSp = Console.ReadLine();
                if (ds.KtraMaSP(MaSp) == true)
                {
                    Console.WriteLine("Ma san pham da ton tai. Vui long nhap lai:");
                }
            }
            while (ds.KtraMaSP(MaSp) == true);
            if (MaSp.Trim().Length > 0)
                this.Masp = MaSp;

            //Cập nhật Tên sản phẩm
            Console.Write("Nhap Ten san pham: ");
            TenSp = Console.ReadLine();
            if (MaSp.Trim().Length > 0)
                this.Tensp = TenSp;

            //Cập nhật số lượng
            Console.Write("Nhap so luong (so luong>0): ");
            int.TryParse(Console.ReadLine().Replace(" ", ""), out Soluong);
            if (Soluong > 0)
                this.Soluong = Soluong;

            //Cập nhật đơn giá nhập
            Console.Write("Nhap don gia nhap (don gia nhap>0): ");
            double.TryParse(Console.ReadLine().Replace(" ", ""), out Gianhap);
            if (Gianhap > 0)
                this.Gianhap = Gianhap;

            //Cập nhật đơn giá bán
            Console.Write("Nhap don gia ban (don gia ban>0 va >= don gia nhap): ");
            double.TryParse(Console.ReadLine().Replace(" ", ""), out Giaban);
            if (Giaban > 0 && Giaban >= this.Gianhap)
                this.Giaban = Giaban;

            //Cập nhật ngày nhập hàng
            Console.Write("Nhap Ngay nhap hang :");
            Ngaynhap = Console.ReadLine();
            if (Ngaynhap.Trim().Length > 0)
                this.Ngaynhap = Ngaynhap;
        }

        //PHƯƠNG THỨC toString(chuyển đối tượng thành 1 chuỗi)
        public String toString()
        {
            string str = Masp + "#" + Tensp + "#" + Ngaynhap + "#" + Soluong + "#" + Gianhap + "#" + Giaban;
            return str;
        }

        //PHƯƠNG THỨC HIỂN THỊ
        public void Hien()
        {

            Console.WriteLine("   {0,-5}  {1,-15} {2,10} {3,5}  {4,7}  {5,7} ", Masp, Tensp, Ngaynhap, Soluong, Gianhap, Giaban);

        }
        public double Tinhtien()
        {
            return Soluong * Giaban;
        }
    }
}
