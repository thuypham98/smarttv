﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace QLCuaHangTivi
{
    class DSTV
    {
        private List<TiVi> list;
        public DSTV()
        {
            list = new List<TiVi>();
        }

        public void Hien()
        {
            int stt = 1;
            Console.WriteLine("{0,-3}  {1,-10} {2,-10}  {3,10}  {4,-5}  {5,6}  {6,6}", "STT","Mã SP","Tên SP", "Ngày Nhập", "Số Lượng", "Giá Nhập", "Giá Bán");
            foreach (TiVi sp in list)
            {
                Console.Write("{0,-3}", stt);
                sp.Hien();
                stt++;
            }
        }

        public void HienSPTheoMa(string MaSp)
        {
            Console.WriteLine("{0,-3}  {1,-10}  {2,-10}  {3,10}  {4,-5}  {5,6}  {6,6}", "STT", "Ma SP", "Ten SP", "Ngay nhap", "Soluong", "Gia nhap", "Gia ban");
            foreach (TiVi sp in list)
            {
                if (sp.MASP == MaSp)
                    sp.Hien();
            }
        }

        //Đọc file 
        public void ReadFile(String fileName)
        {
            list = new List<TiVi>();
            StreamReader str = new StreamReader(new FileStream(fileName, FileMode.Open));
            String strTmp;
            String[] tmp;
            while (!str.EndOfStream)
            {
                strTmp = str.ReadLine().Trim();
                if (strTmp != "")
                {
                    tmp = strTmp.Split('#');
                    list.Add(new TiVi((tmp[0]), (tmp[1]), (tmp[2]), (int.Parse(tmp[3])), (double.Parse(tmp[4])), (double.Parse(tmp[5]))));
                }
            }
            str.Close();
        }

        //Ghi file
        public void WriteFile(String fileName)
        {
            StreamWriter str = new StreamWriter(fileName, false);
            foreach (TiVi sp in list)
                str.WriteLine(sp.toString());
            str.Close();
        }

        public void ThemMoi(String fileName)
        {
            ConsoleKeyInfo chon;
            TiVi sp = new TiVi();
            while (true)
            {
                do
                {
                    Console.Write("n/Ban muon them moi mot san pham: (C=Co)/(K=Khong) : ");
                    chon = Console.ReadKey();

                } while (!(chon.KeyChar.ToString().ToUpper() == "C" || chon.KeyChar.ToString().ToUpper() == "K"));
                if (chon.KeyChar.ToString().ToUpper() == "K")
                    break; // Thoát khỏi cấu trúc while
                else // Nhập thông tin của sản phẩm mới nếu người dùng nhập Y
                {
                    sp.Nhap();
                    //Them sản phẩm vao list
                    list.Add(sp);
                    //ghi du lieu vao cuoi file
                    StreamWriter str = new StreamWriter(new FileStream(fileName, FileMode.Append));
                    str.WriteLine(sp.toString());
                    str.Close();
                }
            }
        }

        public bool KtraMaSP(string maSp) // phục vụ hoá đơn bán, nếu mà sl trong kho ít hơn sl trong hdb vừa nhập
        {
            bool kt = false;

            foreach (TiVi sp in list)
            {
                if (sp.MASP == maSp)// rktra
                {
                    kt = true; // thay đổi gtri biến ktra// quên chưa CÓ >'< cho luôm d
                }
            }
            return kt;
        }

        public void CapNhat()
        {

            string MaSP;
            Console.WriteLine("==========================================");
            Console.WriteLine("        SUA THONG TIN SAN PHAM!!!         ");
            Console.WriteLine("==========================================");
            Console.Write("Nhap ma san pham muon sua:");
            MaSP = Console.ReadLine();

            TiVi sp = TimkiemTheoMa(MaSP);
            if (sp == null)
                Console.WriteLine("KHONG CO MA SAN PHAM: {0} TRONG DANH SACH SAN PHAM !?", MaSP);
            else
            {
                sp.Hien();
                sp.CapNhatSP();
                //Console.WriteLine("Sua thong tin san pham thanh cong.");
            }
        }

        public void Xoa(String MaSP)
        {
            //int i = 0;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].MASP == MaSP)
                {
                    list.RemoveAt(i);
                    break;
                }
            }
        }

        public void Nhap()
        {
            int stt = 1;
            foreach (TiVi sp in list)
            {
                Console.Write("{0,-3}", stt);
                sp.Nhap();
                stt++;
            }
        }
        public void TimkiemTheoTenSP(string TenSP)
        {
            int dem = 0;
            Console.WriteLine("{0,-3}  {1,-10}  {2,-10}  {3,10}  {4,-5}  {5,6}  {6,6}", "STT", "Ma san pham", "Ten san pham", "Ngay nhap", "Soluong", "Gia nhap", "Gia ban");
            foreach (TiVi sp in list)
            {
                if (sp.TENSP == TenSP)
                {
                    sp.Hien();
                    dem++;
                }
            }
            if (dem == 0)
                Console.WriteLine("Khong co ten san pham la: {0}", TenSP);
        }

        public TiVi TimkiemTheoMa(string Masp)
        {
            for (int i = 0; i < list.Count; i++)
                if (Masp.CompareTo(list[i].MASP) == 0)
                {
                    return list[i];
                }
            return null;
        }


        public int Count()
        {
            int t = 0;
            foreach (TiVi sp in list)
            {
                if (sp.MASP != "")
                    t = t + 1;
            }
            return t;
        }
        public double TongTien()
        {
            double t = 0;
            foreach (TiVi sp in list)
                t = t + sp.Tinhtien();
            return t;
        }

        public void MenuSanPham()
        {
            Console.Title = "\t";
            bool stop = false;
            while (!stop)
            {
                Console.Clear();
                //Console.SetWindowSize(115, 50);
                Console.Write("                      ╔═══════════════════════════════════════════════════════════════════╗\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ║       F1 : Hiển Thị DS Sản Phâm         F2 : Thêm Sản Phẩm Mới    ║\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ║       F3 : Cập Nhật Sản Phẩm            F4 : Xóa Sản Phẩm         ║\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ║       F5 : Tìm Kiếm Sản Phẩm            F6 : Quay Lại Menu Chính  ║\n");
                Console.Write("                      ║                                                                   ║\n");
                Console.Write("                      ╚═══════════════════════════════════════════════════════════════════╝\n\n");

                Console.Write("                                        Mời Bạn Chọn Phím Chức Năng: ");
                //Console.SetCursorPosition(52, 22);
                ConsoleKeyInfo kt = Console.ReadKey();
                Console.Clear();
                DSTV SP = new DSTV();
                SP.ReadFile("D:\\SanPham.txt");
                switch (kt.Key)
                {
                    case ConsoleKey.F1:
                        SP.Hien();
                        Console.ReadKey();
                        break;
                    case ConsoleKey.F2:
                        SP.ThemMoi("D:\\SanPham.txt");
                        break;
                    case ConsoleKey.F3:
                        SP.CapNhat();
                        SP.Hien();
                        SP.WriteFile("D:\\SanPham.txt");
                        Console.ReadKey();
                        break;
                    case ConsoleKey.F4:
                        Console.WriteLine(" Nhap Ma san pham can xoa: ");
                        string MaSP = Console.ReadLine();
                        TiVi sp = SP.TimkiemTheoMa(MaSP);
                        if (sp == null)
                            Console.WriteLine(" Khong co san pham co ma : {0}. ", MaSP);
                        else
                        {
                            SP.Xoa(MaSP);
                            SP.Hien();
                            SP.WriteFile("D:\\SanPham.txt");
                            Console.ReadKey();
                        }
                        break;
                    case ConsoleKey.F5:// Hiện danh sách
                        Console.Write("\nNhap ten san pham can tim kiem : ");
                        string TenSP = Console.ReadLine();
                        SP.TimkiemTheoTenSP(TenSP);
                        Console.ReadKey();
                        break;
                    case ConsoleKey.F6:
                        // Environment.Exit(0);
                        return;
                    //  break;
                    default:
                        break;
                }
            }
        }
    }
}
